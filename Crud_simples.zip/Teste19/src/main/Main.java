package main;

import view.login;

public class Main {
    public static void main(String[] args)  {
       new login().setVisible(true);
    }   
}
