/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author vinic
 */
public class viagem {
        
    private int Serie;
    private String nome;
    private String nomeCidade;
    private String UF;
    private double PesoTonelada;
    private double DistanciaKM;
    private double Valor;
    private int id_motrista;

    public int getSerie() {
        return Serie;
    }

    public void setSerie(int Serie) {
        this.Serie = Serie;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNomeCidade() {
        return nomeCidade;
    }

    public void setNomeCidade(String nomeCidade) {
        this.nomeCidade = nomeCidade;
    }

    public String getUF() {
        return UF;
    }

    public void setUF(String UF) {
        this.UF = UF;
    }

    public double getPesoTonelada() {
        return PesoTonelada;
    }

    public void setPesoTonelada(double PesoTonelada) {
        this.PesoTonelada = PesoTonelada;
    }

    public double getDistanciaKM() {
        return DistanciaKM;
    }

    public void setDistanciaKM(double DistanciaKM) {
        this.DistanciaKM = DistanciaKM;
    }

    public double getValor() {
        return Valor;
    }

    public void setValor(double Valor) {
        this.Valor = Valor;
    }

    public int getId_motrista() {
        return id_motrista;
    }

    public void setId_motrista(int id_motrista) {
        this.id_motrista = id_motrista;
    }

    
    
}
