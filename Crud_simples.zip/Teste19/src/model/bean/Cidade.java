/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.bean;

/**
 *
 * @author vinic
 */
public class Cidade {
    
    private String NomeCidade;

    public String getNomeCidade() {
        return NomeCidade;
    }

    public void setNomeCidade(String NomeCidade) {
        this.NomeCidade = NomeCidade;
    }

    public String getUF() {
        return UF;
    }

    public void setUF(String UF) {
        this.UF = UF;
    }
    private String UF; 
   

}
