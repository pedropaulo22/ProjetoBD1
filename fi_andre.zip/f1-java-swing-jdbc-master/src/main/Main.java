package main;

import ui.frmPrincipal;

/**
 *
 * @author André Schwerz
 */
public class Main {
    public static void main(String[] args)  {
       new frmPrincipal().setVisible(true);
    }   
}
