package dao;

/**
 *
 * @author André Schwerz
 */
public class Config {
    public static final String URL = "jdbc:mysql://localhost/F1?useSSL=false";
    public static final String LOGIN = "root";
    public static final String PASSWORD = "root"; 
}